from django.contrib import admin
from django.urls import path,include
from Games import views
app_name="Games"
urlpatterns=[path("",views.landing_page,name="landing page"),
             path("game",views.Murder_mystery,name="game"),
             path("login",views.user_login,name="login"),
             path("signup",views.user_signup,name="Signup")]