from django.shortcuts import render,HttpResponse
import mysql.connector as msql
from django.contrib.auth import authenticate,login
from django.contrib.auth.models import User
from Games import models
# Create your views here.
connection_obj=msql.connect(host="localhost",
    user="root",
    password="") 
cursor_obj=connection_obj.cursor()
def landing_page(request):
    '''if request.method=="POST":
        form_data=User_roll_no(request.POST)
    print(form_data)
    if form_data.is_valid():
            roll_number = form_data.cleaned_data['roll_number']
    print(form_data.cleaned_data)'''
    cursor_obj.execute("use student")
    cursor_obj.execute("select * from exam_result ")
    row=cursor_obj.fetchall()
    cursor_obj.execute ("desc exam_result")
    col_heading=cursor_obj.fetchall()
    context={'data':row,'col':col_heading}
    return render(request,'rough.html',context)
def Murder_mystery(request):
    return render(request,'murder_mystery.html') 
def user_login(request):
    if request.method=="POST":
        username=request.POST.get("username")
        password=request.POST.get("password")
        Myuser=authenticate(request,username=username,password=password)
        if Myuser is not None:
            login(request,Myuser)
        else:
            return HttpResponse("Wrong username or password")
    else:
        return render(request,'login_page.html')
def user_signup(request):
    if request.method=="POST":
        username=request.POST.get("username")
        email=request.POST.get("email")
        password1=request.POST.get("pass1")
        password2=request.POST.get("pass2")
        if password1!=password2:
            return HttpResponse("Your password doesn't match ")
        else:
            My_user=User.objects.create(username,email,password1)
    return render(request,'signup_page.html')


'''
def Locke_key(request):
    render(request,'locke_Key.html')'''
