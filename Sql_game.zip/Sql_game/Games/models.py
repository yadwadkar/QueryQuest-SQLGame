from django.db import models
from django import forms

# Create your models here.
class User_roll_no(forms.Form):
    roll_no=forms.IntegerField()
    

